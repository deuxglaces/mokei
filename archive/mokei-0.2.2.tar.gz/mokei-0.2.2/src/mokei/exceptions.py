class MokeiException(Exception):
    pass


class MokeiConfigError(MokeiException):
    pass
