from aiohttp import web_request


class Request(web_request.Request):
    pass
